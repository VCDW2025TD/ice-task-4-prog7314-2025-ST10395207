package com.example.memestream.notifications

import android.util.Log
import com.google.firebase.messaging.FirebaseMessaging
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

object TokenManager {
    private const val SERVER_URL = "https://your-backend.com/api/saveToken"

    fun saveTokenToBackend(token: String) {
        val client = OkHttpClient()

        val json = JSONObject()
        json.put("fcmToken", token)
        // optionally also send "userId"

        val requestBody = RequestBody.create(
            "application/json".toMediaTypeOrNull(),
            json.toString()
        )

        val request = Request.Builder()
            .url(SERVER_URL)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("TokenManager", "Failed to send token", e)
            }

            override fun onResponse(call: Call, response: Response) {
                Log.d("TokenManager", "Token sent successfully")
            }
        })
    }

    fun fetchCurrentToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val token = task.result
                saveTokenToBackend(token)
            }
        }
    }
}
