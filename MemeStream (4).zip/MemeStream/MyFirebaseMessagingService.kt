package com.example.memestream.notifications

import android.os.Build
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        remoteMessage.notification?.let {
            NotificationUtils.showNotification(
                context = this,
                title = it.title ?: "MemeStream",
                message = it.body ?: "New meme update!"
            )
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        TokenManager.saveTokenToBackend(token)
    }
}
