@Entity(tableName = "memes")
data class MemeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val imageUrl: String,
    val userId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
)
