class MemeSyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val db = MemeDatabase.getDatabase(applicationContext)
        val repo = MemeRepository(db.memeDao(), MemeApi.create())
        repo.syncUnsyncedMemes()
        return Result.success()
    }
}
