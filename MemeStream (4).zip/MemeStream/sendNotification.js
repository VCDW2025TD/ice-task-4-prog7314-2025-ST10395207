import fetch from "node-fetch";

export async function sendFCMNotification(title, body, fcmToken) {
  const response = await fetch("https://fcm.googleapis.com/fcm/send", {
    method: "POST",
    headers: {
      "Authorization": "key=YOUR_SERVER_KEY",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      to: fcmToken,
      notification: { title, body }
    })
  });

  return response.json();
}
