interface MemeApi {
    @POST("/memes")
    suspend fun postMeme(@Body meme: MemeEntity)

    @GET("/memes")
    suspend fun getMemes(): List<MemeEntity>

    companion object {
        fun create(): MemeApi {
            val retrofit = Retrofit.Builder()
                .baseUrl("https://your-api-url.com/") // replace with your hosted API
                .addConverterFactory(GsonConverterFactory.create())
                .build()
            return retrofit.create(MemeApi::class.java)
        }
    }
}
