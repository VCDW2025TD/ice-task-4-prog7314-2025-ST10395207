@Dao
interface MemeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeme(meme: MemeEntity)

    @Query("SELECT * FROM memes ORDER BY createdAt DESC")
    suspend fun getAllMemes(): List<MemeEntity>

    @Query("SELECT * FROM memes WHERE userId = :userId")
    suspend fun getMemesByUser(userId: String): List<MemeEntity>

    @Query("SELECT * FROM memes WHERE isSynced = 0")
    suspend fun getUnsyncedMemes(): List<MemeEntity>

    @Update
    suspend fun updateMeme(meme: MemeEntity)
}
