class MemeRepository(
    private val memeDao: MemeDao,
    private val api: MemeApi
) {
    suspend fun addMeme(meme: MemeEntity) {
        try {
            api.postMeme(meme) // Retrofit API call
            memeDao.insertMeme(meme.copy(isSynced = true))
        } catch (e: Exception) {
            memeDao.insertMeme(meme) // save unsynced
        }
    }

    suspend fun getMemes(): List<MemeEntity> = memeDao.getAllMemes()

    suspend fun syncUnsyncedMemes() {
        val unsynced = memeDao.getUnsyncedMemes()
        for (meme in unsynced) {
            try {
                api.postMeme(meme)
                memeDao.updateMeme(meme.copy(isSynced = true))
            } catch (_: Exception) { }
        }
    }
}
